#include <iostream>
#include <fstream>
#include <conio.h>
#include <ctime>
using namespace std;
	int jumlahBarang, menu;
	int banyakBarang, hargaTotal;
	int hargaBarang[100];
	char namaBarang[100][30];
	time_t now=time(0);
	char* dt=ctime (&now);
	char adaDiskon[30];
	void Rules();
void WelcomeMessage(){
	cout<<"------ KASIR SWALAYAN ANTAH BERANTAH ------"<<endl;
	cout<<"--> "<<dt<<endl;
}
void diskon(){
	cout<<"Apakah ada kartu diskon ? Y/N --> "; cin>>adaDiskon;
	if (adaDiskon == "Y"){
		cout<<"Kartu diskon ada kadaluarsa :) "<<endl;
	}
	else {
		cout<<".."<<endl;
	}
}
void login(){
	string user,pass;
	cout<<"Masukkan Nama Pengguna : "; cin>>user;
	cout<<"Masukkan Katasandi : "; cin>>pass;
	
	if (user=="Aziyan" && pass=="sama"){
	system("CLS");
		cout<<"Selamat Datang Kembali Pak,- "<<endl;
	}
	else{
		cout<<"Login Error"<<endl;
		login();
	}
}
void output(){
	cout<<"----------- Barang yang Anda Beli -----------"<<endl;
	for (int x=0; x<jumlahBarang; x++){
		cout<<namaBarang[x]<<" "<<hargaBarang[x]<<endl;
	}
	cout<<"---------------------------- + "<<endl;
	cout<<"Total :  Rp."<<hargaTotal<<endl;
}
void input(){
	cout<<"Masukkan jumlah barang : "; cin>>jumlahBarang;
	for (int x=0; x<jumlahBarang; x++ ){
			cout<<"Nama Barang : "; cin>>namaBarang[x];
			cout<<"Harga Barang : "; cin>>hargaBarang[x];
		}
			cout<<"-----------------"<<endl;
}
void proses(){
	hargaTotal=0;
	for (int x=0; x<jumlahBarang; x++){
		hargaTotal=hargaTotal+hargaBarang[x];	
	}
}
void save(){
	ofstream file;
	file.open("KasirDB.txt");
	file<<"Barang yang dibeli"<<endl;
	for (int x=0; x<jumlahBarang; x++){
	file<<namaBarang[x]<<" Rp. "<<hargaBarang[x]<<endl;
	}
	file<<"Total : Rp."<<hargaTotal<<endl;
	file<<dt<<endl;
	file.close();
}
void Menu(){
	cout<<"Menu : "<<endl;
	cout<<"[1] Lanjut "<<endl;
	cout<<"[2] Keluar "<<endl;
	cout<<" Menu : "; cin>>menu;
	if (menu == 1){
		Rules();
	}
	else if (menu == 2){
		system ("CLS");
		cout<<"Good Bye :) "<<endl;
	}
	else {
		cout<<"Error"<<endl;
		Menu();
	}
}
void Rules(){
 	WelcomeMessage();
	input();
	proses();
	system ("CLS");
	output();
	save();
	Menu();
}
void exit(){
	    cout << "**************************************" << endl;
        cout << "**************************************" << endl;
        cout << "*******    T H A N K  Y O U    *******" << endl;
        cout << "*******    F O R  U S I N G    *******" << endl;
        cout << "*********          US    *************" << endl;
        cout << "**************************************" << endl;
        cout << "**************************************" << endl;
}
int main(){
	cout<<"You Must Login First "<<endl;
	cout<<"---> "<<dt<<endl;
	login();
	Rules();
	system ("PAUSE");
}
